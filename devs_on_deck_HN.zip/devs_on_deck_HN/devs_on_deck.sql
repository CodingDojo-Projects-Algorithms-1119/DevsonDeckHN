-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema devs_on_deck
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `devs_on_deck` ;

-- -----------------------------------------------------
-- Schema devs_on_deck
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `devs_on_deck` DEFAULT CHARACTER SET utf8 ;
USE `devs_on_deck` ;

-- -----------------------------------------------------
-- Table `devs_on_deck`.`users`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `devs_on_deck`.`users` ;

CREATE TABLE IF NOT EXISTS `devs_on_deck`.`users` (
  `user_id` INT NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(255) NULL,
  `last_name` VARCHAR(255) NULL,
  `address` VARCHAR(255) NULL,
  `city` VARCHAR(255) NULL,
  `state` VARCHAR(255) NULL,
  `email` VARCHAR(255) NULL,
  `password` VARCHAR(255) NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`user_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `devs_on_deck`.`organizations`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `devs_on_deck`.`organizations` ;

CREATE TABLE IF NOT EXISTS `devs_on_deck`.`organizations` (
  `organization_id` INT NOT NULL AUTO_INCREMENT,
  `org_name` VARCHAR(255) NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`organization_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `devs_on_deck`.`languages`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `devs_on_deck`.`languages` ;

CREATE TABLE IF NOT EXISTS `devs_on_deck`.`languages` (
  `language_id` INT NOT NULL AUTO_INCREMENT,
  `lang_name` VARCHAR(255) NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`language_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `devs_on_deck`.`frameworks`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `devs_on_deck`.`frameworks` ;

CREATE TABLE IF NOT EXISTS `devs_on_deck`.`frameworks` (
  `frw_id` INT NOT NULL AUTO_INCREMENT,
  `frw_name` VARCHAR(255) NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`frw_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `devs_on_deck`.`skills`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `devs_on_deck`.`skills` ;

CREATE TABLE IF NOT EXISTS `devs_on_deck`.`skills` (
  `skill_id` INT NOT NULL AUTO_INCREMENT,
  `bio` VARCHAR(255) NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  `u_id` INT NOT NULL,
  PRIMARY KEY (`skill_id`),
  INDEX `fk_skills_users1_idx` (`u_id` ASC),
  CONSTRAINT `fk_skills_users1`
    FOREIGN KEY (`u_id`)
    REFERENCES `devs_on_deck`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `devs_on_deck`.`positions`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `devs_on_deck`.`positions` ;

CREATE TABLE IF NOT EXISTS `devs_on_deck`.`positions` (
  `position_id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) NULL,
  `description` VARCHAR(255) NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  `org_id` INT NOT NULL,
  PRIMARY KEY (`position_id`),
  INDEX `fk_positions_users1_idx` (`org_id` ASC),
  CONSTRAINT `fk_positions_users1`
    FOREIGN KEY (`org_id`)
    REFERENCES `devs_on_deck`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `devs_on_deck`.`users_oranizations`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `devs_on_deck`.`users_oranizations` ;

CREATE TABLE IF NOT EXISTS `devs_on_deck`.`users_oranizations` (
  `u_id` INT NOT NULL,
  `o_id` INT NOT NULL,
  PRIMARY KEY (`u_id`, `o_id`),
  INDEX `fk_users_has_oranizations_oranizations1_idx` (`o_id` ASC),
  INDEX `fk_users_has_oranizations_users1_idx` (`u_id` ASC),
  CONSTRAINT `fk_users_has_oranizations_users1`
    FOREIGN KEY (`u_id`)
    REFERENCES `devs_on_deck`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_has_oranizations_oranizations1`
    FOREIGN KEY (`o_id`)
    REFERENCES `devs_on_deck`.`organizations` (`organization_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `devs_on_deck`.`users_languages`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `devs_on_deck`.`users_languages` ;

CREATE TABLE IF NOT EXISTS `devs_on_deck`.`users_languages` (
  `u_id` INT NOT NULL,
  `l_id` INT NOT NULL,
  PRIMARY KEY (`u_id`, `l_id`),
  INDEX `fk_users_has_languages_languages1_idx` (`l_id` ASC),
  INDEX `fk_users_has_languages_users1_idx` (`u_id` ASC),
  CONSTRAINT `fk_users_has_languages_users1`
    FOREIGN KEY (`u_id`)
    REFERENCES `devs_on_deck`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_has_languages_languages1`
    FOREIGN KEY (`l_id`)
    REFERENCES `devs_on_deck`.`languages` (`language_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `devs_on_deck`.`users_frameworks`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `devs_on_deck`.`users_frameworks` ;

CREATE TABLE IF NOT EXISTS `devs_on_deck`.`users_frameworks` (
  `f_id` INT NOT NULL,
  `u_id` INT NOT NULL,
  PRIMARY KEY (`f_id`, `u_id`),
  INDEX `fk_frameworks_has_users_users1_idx` (`u_id` ASC),
  INDEX `fk_frameworks_has_users_frameworks1_idx` (`f_id` ASC),
  CONSTRAINT `fk_frameworks_has_users_frameworks1`
    FOREIGN KEY (`f_id`)
    REFERENCES `devs_on_deck`.`frameworks` (`frw_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_frameworks_has_users_users1`
    FOREIGN KEY (`u_id`)
    REFERENCES `devs_on_deck`.`users` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `devs_on_deck`.`positions_frameworks`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `devs_on_deck`.`positions_frameworks` ;

CREATE TABLE IF NOT EXISTS `devs_on_deck`.`positions_frameworks` (
  `p_id` INT NOT NULL,
  `f_id` INT NOT NULL,
  PRIMARY KEY (`p_id`, `f_id`),
  INDEX `fk_positions_has_frameworks_frameworks1_idx` (`f_id` ASC),
  INDEX `fk_positions_has_frameworks_positions1_idx` (`p_id` ASC),
  CONSTRAINT `fk_positions_has_frameworks_positions1`
    FOREIGN KEY (`p_id`)
    REFERENCES `devs_on_deck`.`positions` (`position_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_positions_has_frameworks_frameworks1`
    FOREIGN KEY (`f_id`)
    REFERENCES `devs_on_deck`.`frameworks` (`frw_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `devs_on_deck`.`positions_languages`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `devs_on_deck`.`positions_languages` ;

CREATE TABLE IF NOT EXISTS `devs_on_deck`.`positions_languages` (
  `p_id` INT NOT NULL,
  `l_id` INT NOT NULL,
  PRIMARY KEY (`p_id`, `l_id`),
  INDEX `fk_positions_has_languages_languages1_idx` (`l_id` ASC),
  INDEX `fk_positions_has_languages_positions1_idx` (`p_id` ASC),
  CONSTRAINT `fk_positions_has_languages_positions1`
    FOREIGN KEY (`p_id`)
    REFERENCES `devs_on_deck`.`positions` (`position_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_positions_has_languages_languages1`
    FOREIGN KEY (`l_id`)
    REFERENCES `devs_on_deck`.`languages` (`language_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
