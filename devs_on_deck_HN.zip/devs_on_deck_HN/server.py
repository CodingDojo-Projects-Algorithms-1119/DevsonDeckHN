from flask import Flask, render_template, redirect, request, flash, session
from mysqlconnection import connectToMySQL
from flask_bcrypt import Bcrypt
from datetime import datetime
import re

app = Flask(__name__)
app.secret_key = ('pikachu')
bcrypt = Bcrypt(app)
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 

@app.route('/devs')
def developer_signup():
    return render_template('developer_signup.html')

@app.route('/orgs')
def organization_signup():
    return render_template('organization_signup.html')

@app.route('/devs_signup', methods=["POST"])
def user_register():
    is_valid = True
    if len(request.form['fn']) < 2:
        is_valid = False
        flash('First name must be at least 2 characters.')
    if len(request.form['ln']) < 2:
        is_valid = False
        flash('Last name must be at least 2 characters.')
    if not EMAIL_REGEX.match(request.form['em']):
        is_valid = False
        flash('Please enter valid email.')
    mysql = connectToMySQL('devs_on_deck')
    query = 'SELECT * FROM users WHERE email=%(e_m)s;'
    data = {'e_m': request.form['em']}
    user = mysql.query_db(query,data)
    if user:
        is_valid = False
        flash('Email is already exist. Please choose another email.')
    if len(request.form['ad']) < 1:
        is_valid = False
        flash('Please enter address.')
    if len(request.form['ct']) < 1:
        is_valid = False
        flash('Please enter city.')
    if len(request.form['st']) < 1:
        is_valid = False
        flash('Please enter state.')
    if len(request.form['pw']) < 8:
        is_valid = False
        flash('Password must be at least 8 characters.')
    if request.form['c_pw'] != request.form['pw']:
        is_valid = False
        flash('Passwords must match.')
    if not is_valid:
        return redirect('/devs')
    else:
        encrypted_pw = bcrypt.generate_password_hash(request.form['pw'])
        mysql = connectToMySQL('devs_on_deck')
        query = "INSERT INTO users(first_name, last_name, address, city, state, email, password, created_at, updated_at) VALUES(%(f_n)s, %(l_n)s, %(a_d)s, %(c_t)s, %(s_t)s, %(e_m)s, %(p_w)s, NOW(), NOW());"
        data = {
            'f_n': request.form['fn'],
            'l_n': request.form['ln'],
            'e_m': request.form['em'],
            'a_d': request.form['ad'],
            'c_t': request.form['ct'],
            's_t': request.form['st'],
            'p_w': encrypted_pw
        }
        user_id = mysql.query_db(query, data)
        session['user_id'] = user_id
        mysql = connectToMySQL('devs_on_deck')
        query = 'SELECT * FROM languages;'
        langs = mysql.query_db(query)
        return render_template('add_skills.html', user_id=user_id, langs=langs)

@app.route('/add_bio', methods = ['POST'])
def validate_process_bio():
    is_valid = True
    if len(request.form['bio'])<5:
        is_valid = False
        flash('Bio must be at least 5 characters.')
    if len(request.form['bio'])>255:
        is_valid = False
        flash('Bio must be less than 255 characters.')
    if is_valid:
        mysql = connectToMySQL('devs_on_deck')
        query = 'INSERT INTO skills(bio, created_at, updated_at, u_id) VALUES(%(bio)s, NOW(), NOW(), %(u_id)s);'
        data = {
            'bio': request.form['bio'],
            'u_id': session['user_id']
        }
        mysql.query_db(query, data)
        mysql = connectToMySQL('devs_on_deck')
        query = 'SELECT frameworks.frw_id, frameworks.frw_name, users_frameworks.u_id FROM users_frameworks JOIN frameworks ON frameworks.frw_id=users_frameworks.f_id WHERE users_frameworks.u_id=%(u_id)s;'
        data = {
            'u_id': session['user_id']
        }
        frameworks = mysql.query_db(query, data)
        mysql = connectToMySQL('devs_on_deck')
        query = 'SELECT * FROM frameworks;'
        frames = mysql.query_db(query)
        return render_template('add_frameworks.html', frameworks=frameworks, frames=frames)
    else:
        mysql = connectToMySQL('devs_on_deck')
        query = 'SELECT languages.language_id, languages.lang_name, users_languages.u_id FROM users_languages JOIN languages ON languages.language_id=users_languages.l_id WHERE users_languages.u_id=%(u_id)s;'
        data = {
            'u_id': session['user_id']
        }
        languages = mysql.query_db(query, data)
        mysql = connectToMySQL('devs_on_deck')
        query = 'SELECT * FROM languages;'
        langs = mysql.query_db(query)
        return render_template('add_skills.html', languages=languages, langs=langs)

@app.route('/add_language', methods=["POST"])   
def languages():
    is_valid = True
    if len(request.form['lg']) < 1:
        is_valid = False
        flash('Please select a language.')
    else:
        mysql = connectToMySQL('devs_on_deck')
        query = 'SELECT users_languages.l_id, languages.lang_name FROM users_languages JOIN languages ON users_languages.l_id=languages.language_id WHERE users_languages.u_id = %(u_id)s AND languages.lang_name=%(l_g)s;'
        data = {
            'u_id': session['user_id'],
            'l_g': request.form['lg']
        }
        lang_infor = mysql.query_db(query, data)
        if (lang_infor and request.form['lg']==lang_infor[0]['lang_name']):
            is_valid = False
            flash('You have selected this language. Please select another one.')
        else:
            mysql = connectToMySQL('devs_on_deck')
            query = 'SELECT count(l_id) as count FROM users_languages WHERE u_id = %(u_id)s GROUP BY u_id;'
            data = {
                'u_id': session['user_id']
            }
            count = mysql.query_db(query, data)
            if (count and int(count[0]['count']) > 4):
                is_valid = False
                flash('You have added 5 languages. You are not allowed to add more.')
            else:
                mysql = mysql = connectToMySQL('devs_on_deck')
                query = 'SELECT * FROM languages WHERE lang_name=%(l_g)s;'
                data = {
                    'l_g': request.form['lg']
                }
                l_id=mysql.query_db(query, data)
                print(l_id)
                mysql = connectToMySQL('devs_on_deck')
                query = 'INSERT INTO users_languages(u_id, l_id) VALUES(%(u_id)s, %(l_id)s);'
                data = {
                    'u_id': session['user_id'],
                    'l_id': l_id[0]['language_id']
                }
                _=mysql.query_db(query, data)
                
    mysql = connectToMySQL('devs_on_deck')
    query = 'SELECT languages.language_id, languages.lang_name, users_languages.u_id FROM users_languages JOIN languages ON languages.language_id=users_languages.l_id WHERE users_languages.u_id=%(u_id)s;'
    data = {
        'u_id': session['user_id']
    }
    languages = mysql.query_db(query, data)
    mysql = connectToMySQL('devs_on_deck')
    query = 'SELECT * FROM languages;'
    langs = mysql.query_db(query)
    return render_template('add_skills.html', languages=languages, langs=langs)

@app.route('/add_framework', methods=["POST"])   
def frameworks():
    is_valid = True
    if len(request.form['frw']) < 1:
        is_valid = False
        flash('Please select a framework.')
    else:
        mysql = connectToMySQL('devs_on_deck')
        query = 'SELECT users_frameworks.f_id, frameworks.frw_name FROM users_frameworks JOIN frameworks ON users_frameworks.f_id=frameworks.frw_id WHERE users_frameworks.u_id = %(u_id)s AND frameworks.frw_name=%(fr_w)s;'
        data = {
            'u_id': session['user_id'],
            'fr_w': request.form['frw']
        }
        frame_infor = mysql.query_db(query, data)
        if (frame_infor and request.form['frw']==frame_infor[0]['frw_name']):
            is_valid = False
            flash('You have selected this framework. Please select another one.')
        else:
            mysql = connectToMySQL('devs_on_deck')
            query = 'SELECT count(f_id) as count FROM users_frameworks WHERE u_id = %(u_id)s GROUP BY u_id;'
            data = {
                'u_id': session['user_id']
            }
            count = mysql.query_db(query, data)
            if (count and int(count[0]['count']) > 4):
                is_valid = False
                flash('You have added 5 frameworks. You are not allowed to add more.')
            else:
                mysql = mysql = connectToMySQL('devs_on_deck')
                query = 'SELECT * FROM frameworks WHERE frw_name=%(fr_w)s;'
                data = {
                    'fr_w': request.form['frw']
                }
                f_id=mysql.query_db(query, data)
                print(f_id)
                mysql = connectToMySQL('devs_on_deck')
                query = 'INSERT INTO users_frameworks(u_id, f_id) VALUES(%(u_id)s, %(f_id)s);'
                data = {
                    'u_id': session['user_id'],
                    'f_id': f_id[0]['frw_id']
                }
                _=mysql.query_db(query, data)
                
    mysql = connectToMySQL('devs_on_deck')
    query = 'SELECT frameworks.frw_id, frameworks.frw_name, users_frameworks.u_id FROM users_frameworks JOIN frameworks ON frameworks.frw_id=users_frameworks.f_id WHERE users_frameworks.u_id=%(u_id)s;'
    data = {
        'u_id': session['user_id']
    }
    frameworks = mysql.query_db(query, data)
    mysql = connectToMySQL('devs_on_deck')
    query = 'SELECT * FROM frameworks;'
    frames = mysql.query_db(query)
    return render_template('add_frameworks.html', frameworks=frameworks, frames=frames)

@app.route('/delete_framework/<fw_id>')
def delete_frw(fw_id):
    mysql = connectToMySQL('devs_on_deck')
    query = 'DELETE FROM users_frameworks WHERE f_id=%(f_id)s;'
    data = {
        'f_id': fw_id
    }
    mysql.query_db(query, data)
    mysql = connectToMySQL('devs_on_deck')
    query = 'SELECT frameworks.frw_id, frameworks.frw_name, users_frameworks.u_id FROM users_frameworks JOIN frameworks ON frameworks.frw_id=users_frameworks.f_id WHERE users_frameworks.u_id=%(u_id)s;'
    data = {
        'u_id': session['user_id']
    }
    frameworks = mysql.query_db(query, data)
    mysql = connectToMySQL('devs_on_deck')
    query = 'SELECT * FROM frameworks;'
    langs = mysql.query_db(query)
    return render_template('add_skills.html', frameworks=frameworks, frames=frames)

@app.route('/delete_language/<lang_id>')
def on_delete(lang_id):
    mysql = connectToMySQL('devs_on_deck')
    query = 'DELETE FROM users_languages WHERE l_id=%(l_id)s;'
    data = {
        'l_id': lang_id
    }
    mysql.query_db(query, data)
    mysql = connectToMySQL('devs_on_deck')
    query = 'SELECT languages.language_id, languages.lang_name, users_languages.u_id FROM users_languages JOIN languages ON languages.language_id=users_languages.l_id WHERE users_languages.u_id=%(u_id)s;'
    data = {
        'u_id': session['user_id']
    }
    languages = mysql.query_db(query, data)
    mysql = connectToMySQL('devs_on_deck')
    query = 'SELECT * FROM languages;'
    langs = mysql.query_db(query)
    return render_template('add_skills.html', languages=languages, langs=langs)
    
@app.route('/devs_login')
def devs_login():
    return render_template('developer_login.html')

@app.route('/orgs_login')
def orgs_login():
    return render_template('organization_login.html')

@app.route('/skip')
def skip_step():
    return redirect('/devs')

@app.route('/login', methods = ['POST'])
def user_login():
    is_valid = True
    if not request.form['em']:
        is_valid = False
        flash('Please enter an email.')
    if not EMAIL_REGEX.match(request.form['em']):
        is_valid = False
        flash('Please enter a valid email.')
    if not is_valid:
        return render_template('/developer_login.html')
    else:
        mysql = connectToMySQL('devs_on_deck')
        query = 'SELECT * FROM users WHERE users.email = %(e_m)s;'
        data = {'e_m' : request.form['em']}
        user_info = mysql.query_db(query, data)
        if user_info:
            if not request.form['pw']:
                is_valid = False
                flash('Please enter the password.')
            elif not bcrypt.check_password_hash(user_info[0]['password'], request.form['pw']):
                is_valid = False
                flash('Password is not valid.')
            if is_valid:
                session['user_id']=user_info[0]['user_id']
                return redirect('/devs_dashboard')
            else:
                return render_template('/developer_login.html')
        else:
            flash('please enter a valid email address.')
            return render_template('/developer_login.html')

@app.route('/devs_dashboard')
def devs_dashboard():
    return render_template('/devs_dashboard.html')

@app.route('/orgs_signup', methods=["POST"])
def org_register():
    is_valid = True
    if len(request.form['on']) < 2:
        is_valid = False
        flash('Organization name must be at least 2 characters.')
    if len(request.form['fn']) < 2:
        is_valid = False
        flash('First name must be at least 2 characters.')
    if len(request.form['ln']) < 2:
        is_valid = False
        flash('Last name must be at least 2 characters.')
    if not EMAIL_REGEX.match(request.form['em']):
        is_valid = False
        flash('Please enter valid email.')
    mysql = connectToMySQL('devs_on_deck')
    query = 'SELECT * FROM users WHERE email=%(e_m)s;'
    data = {'e_m': request.form['em']}
    user = mysql.query_db(query,data)
    if user:
        is_valid = False
        flash('Email is already exist. Please choose another email.')
    if len(request.form['ad']) < 1:
        is_valid = False
        flash('Please enter address.')
    if len(request.form['ct']) < 1:
        is_valid = False
        flash('Please enter city.')
    if len(request.form['st']) < 1:
        is_valid = False
        flash('Please enter state.')
    if len(request.form['pw']) < 8:
        is_valid = False
        flash('Password must be at least 8 characters.')
    if request.form['c_pw'] != request.form['pw']:
        is_valid = False
        flash('Passwords must match.')
    if not is_valid:
        return redirect('/orgs')
    else:
        encrypted_pw = bcrypt.generate_password_hash(request.form['pw'])
        mysql = connectToMySQL('devs_on_deck')
        query = "INSERT INTO users(first_name, last_name, address, city, state, email, password, created_at, updated_at) VALUES(%(f_n)s, %(l_n)s, %(a_d)s, %(c_t)s, %(s_t)s, %(e_m)s, %(p_w)s, NOW(), NOW());"
        data = {
            'f_n': request.form['fn'],
            'l_n': request.form['ln'],
            'e_m': request.form['em'],
            'a_d': request.form['ad'],
            'c_t': request.form['ct'],
            's_t': request.form['st'],
            'p_w': encrypted_pw
        }
        user_id = mysql.query_db(query, data)
        session['user_id'] = user_id
        mysql = connectToMySQL('devs_on_deck')
        query = "INSERT INTO organizations(org_name, created_at, updated_at) VALUES(%(o_n)s, NOW(), NOW());"
        data = {'o_n': request.form['on']}
        organization_id = mysql.query_db(query, data)
        session['organization_id'] = organization_id
        mysql = connectToMySQL('devs_on_deck')
        query = "INSERT INTO users_oranizations(u_id, o_id) VALUES(%(u_id)s, %(o_id)s);"
        data = {
            'u_id': user_id,
            'o_id': organization_id
        }
        _= mysql.query_db(query, data)
        mysql = connectToMySQL('devs_on_deck')
        query = 'SELECT * FROM organizations WHERE organization_id= %(o_id)s;'
        data = {
            'o_id': organization_id
        }
        organizations = mysql.query_db(query, data)
        organization = organizations[0]
        return render_template('orgs_dashboard.html', organization=organization)

@app.route('/add_position')
def add_position():
    return render_template('add_position.html')

@app.route('/login_org', methods = ['POST'])
def org_login():
    is_valid = True
    if not request.form['em']:
        is_valid = False
        flash('Please enter an email.')
    if not EMAIL_REGEX.match(request.form['em']):
        is_valid = False
        flash('Please enter a valid email.')
    if not is_valid:
        return render_template('organization_login.html')
    else:
        mysql = connectToMySQL('devs_on_deck')
        query = 'SELECT * FROM users WHERE users.email = %(e_m)s;'
        data = {'e_m' : request.form['em']}
        user_info = mysql.query_db(query, data)
        if user_info:
            if not request.form['pw']:
                is_valid = False
                flash('Please enter the password.')
            elif not bcrypt.check_password_hash(user_info[0]['password'], request.form['pw']):
                is_valid = False
                flash('Password is not valid.')
            if is_valid:
                session['user_id']=user_info[0]['user_id']
                mysql = connectToMySQL('devs_on_deck')
                query = 'SELECT * FROM users_oranizations WHERE u_id = %(u_id)s;'
                data = {'u_id' : session['user_id']}
                org_info = mysql.query_db(query, data)
                if org_info:
                    mysql = connectToMySQL('devs_on_deck')
                    query = 'SELECT * FROM organizations WHERE organization_id= %(o_id)s;'
                    data = {
                        'o_id': org_info[0]['o_id']
                    }
                    organizations = mysql.query_db(query, data)
                    organization = organizations[0]
                    return render_template('orgs_dashboard.html', organization=organization)
                else:
                    is_valid = False
                    flash('You are not an organization. Plesae log in as developer.')
                    return render_template('developer_login.html')
            else:
                return render_template('organization_login.html')
        else:
            flash('please enter a valid email address.')
            return render_template('organization_login.html')

@app.route('/add_new_pos', methods = ['POST'])
def validate_process_pos():
    is_valid = True
    if len(request.form['pn'])<2:
        is_valid = False
        flash('Position must be at least 2 characters.')
    if len(request.form['p_des'])<5:
        is_valid = False
        flash('Position description must be at least 5 characters.')
    if len(request.form['p_des'])>255:
        is_valid = False
        flash('Position description must be less than 255 characters.')
    if is_valid:
        mysql = connectToMySQL('devs_on_deck')
        query = 'SELECT * FROM users_oranizations WHERE u_id = %(u_id)s;'
        data = {
            'u_id' : session['user_id']
        }
        user_org = mysql.query_db(query,data)
        print(user_org)
        org_id = user_org[0]['o_id']
        mysql = connectToMySQL('devs_on_deck')
        query = 'INSERT INTO positions(name, description, created_at, updated_at, org_id) VALUES(%(p_n)s, %(p_des)s, NOW(), NOW(), %(o_id)s);'
        data = {
            'p_n': request.form['pn'],
            'p_des': request.form['p_des'],
            'o_id' : org_id
        }
    return render_template('add_position.html')
    
@app.route('/logout')
def user_logout():
    session.clear()
    return redirect('/devs')

if __name__ == '__main__':
    app.run(debug=True)